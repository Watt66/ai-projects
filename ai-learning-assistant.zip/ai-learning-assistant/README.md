# AI Learning Assistant Chatbot
Simple Flask chatbot using LLM + keyword retrieval.