from flask import Flask, request, jsonify
from openai import OpenAI
import json
import os

app = Flask(__name__)
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# Load documents
with open("documents.json", "r") as f:
    DOCS = json.load(f)

def retrieve_answer(question):
    for doc in DOCS:
        if doc["keyword"].lower() in question.lower():
            return doc["answer"]
    return None

@app.route("/ask", methods=["POST"])
def ask():
    data = request.json
    question = data["question"]
    retrieved = retrieve_answer(question)

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are a study assistant."},
            {"role": "user", "content": f"Question: {question}
Retrieved: {retrieved}"}
        ]
    )
    return jsonify({"answer": response.choices[0].message.content})

if __name__ == "__main__":
    app.run(debug=True)
